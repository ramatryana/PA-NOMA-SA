function G=matrix_generate(G_T,N,L,tSINR,APA)
if APA==1
    L=ceil(G_T^2);
    if L>5
        L=5;
    end
    for iL=1:L
        power(iL)=tSINR*(tSINR+1)^(L-iL);
    end
else
    for iL=1:L
        power(iL)=tSINR*(tSINR+1)^(L-iL);
    end
end


M=G_T*N;
G=zeros(round(M),round(N));
for iM=1:M
    pos_slot=randperm(N);
    pos_power=randperm(L);
    G(iM,pos_slot(1))=power(pos_power(1));
end

