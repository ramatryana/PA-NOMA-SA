function out=lambda_calc(in,fx)
for i=1:length(fx)
Alpha_x(i,:)=fx(i)*(in).^(i-1);
end
Alpha_1=sum(fx);
out=sum(Alpha_x,1)/Alpha_1;