function [T_trial,PLR_trial,Pt_trial]=RA_scheme(G_T,N,DD,PD,nTrial,nFrame,N_iter,L,tSINR,APA)
M=round(G_T*N);
PLR_trial=0;
T_trial=0;
Pt_trial=0;
for iTrial=1:nTrial
    lossFrame=0;
    for iFrame=1:nFrame
        G=matrix_generate(G_T,N,L,tSINR,APA);
        Pt=sum(sum(G,2))/(size(G,1)*size(G,2));
        decodedUser=decoding(G,N_iter,tSINR);
        lossFrame=lossFrame+(M-length(decodedUser));
    end
    PLR=lossFrame/(nFrame*M);
    T=(G_T)*(1-PLR);
    PLR_trial=PLR_trial+PLR/nTrial;
    T_trial=T_trial+T/nTrial;
    Pt_trial=Pt_trial+Pt/nTrial;
    iTrial
end
