clear all;clc;
Figure1=figure(1);
FigW=6;
FigH=5;
set(Figure1,'PaperUnits','inches','Papersize',[FigW,FigH],...
    'Paperposition',[0,0,FigW,FigH],'Units','Inches',...
    'Position',[0,0,FigW,FigH]);
%% NOMA-SA
N=200;
K=2;
G=0.01:0.01:5;

temp=[];
for k=0:K-1
    temp(k+1,:)=((1+G/K).*exp(-G/K)).^k;
end
T_up=G/K.*exp(-G/K).*sum(temp,1);
T_low=G.*exp(-G/K).*((1+G/K).*exp(-G/K)).^(K-1);
plot(G,T_up,'-k','linewidth',1,'markersize',8);hold on;

pos=find(T_up==max(T_up));
T_up_p=T_up;
T_up_p(pos(1):end)=max(T_up);
plot(G,T_up_p,'-b','linewidth',1,'markersize',8);hold on;

pos=find(T_low==max(T_low));
T_low_p=T_low;
T_low_p(pos(1):end)=max(T_low);

plot(G,T_low,'--k','linewidth',1,'markersize',8);hold on;
plot(G,T_low_p,'--b','linewidth',1,'markersize',8);hold on;

%% simulation
nTrial=1000;
nFrame=1;
tSINR=3;
type_PD=1;
PD=1;
DD=[0,1];
G_sim=0.1:0.3:5;
N_iter=1;
step=0.1;
RA_degree=DD;
for iUser=1:length(G_sim)
    [T_sim(iUser),PLR_sim(iUser),Pt_sim(iUser)]=RA_scheme(G_sim(iUser),50,DD,PD,nTrial,nFrame,N_iter,K,tSINR,0);
    iUser
end
plot(G_sim,T_sim,'xk','linewidth',1,'markersize',8);hold on;

pos=find(T_sim==max(T_sim));
T_sim_p=T_sim;
T_sim_p(pos(1):end)=max(T_sim);

plot(G_sim,T_sim_p,'xb','linewidth',1,'markersize',8);hold on;

legend({'Upper-bound NOMA-SA [4]','Upper-bound Proposed','Lower-bound NOMA-SA [4]','Lower-bound Proposed','Simulation NOMA-SA [4]','Simulation Proposed'})
xlabel('Normalized Offered Traffic (G)');
ylabel('Normalized Throughput (T)');