clear all;clc;
N=200;
for K=2:5
G=0.01:0.01:5;
temp=[];
for k=0:K-1
    temp(k+1,:)=((1+G/K).*exp(-G/K)).^k;
end
T_up=G/K.*exp(-G/K).*sum(temp,1);
T_low=G.*exp(-G/K).*((1+G/K).*exp(-G/K)).^(K-1);
plot(G,T_up,'-k');hold on;
plot(G,T_low,'--k');hold on;
end

